package com.example.sakhi.live_scoure.App;

/**
 * Created by zeeshan on 3/18/2017.
 */
public class Constants {
    public String series_name;
    public String id,team1_id,team2_id,srs,batteamscore, overs, runs,mchDesc,status, mnum,matchId,datapath,team1_sName,team2_sName,flag,team2_flag,type,TW,decisn,team1_fName,team2_fName;
    public String mchState,bowlteamscore,batteamid,bowlteamid;
    public String vcity,vcountry,stTme;
    public String  batsmanId_ing1,outdescription_ing1,run_ing1,ball_ing1,four_ing1,six_ing1,sr_ing1,battingteamid;
    public String bowlerId;
    public String bowler_over;
    public String maiden;
    public String run;
    public String bowler_wicket;
    public String noball;
    public String wideball;
    public String sr;
    public String player_id,player_fName,player_name,value_squad_team2 , news_id , news_datapath,hline,intro,location,news_date,src,isE,topic_name ;
    public String author_name,relatedStoriesCount,img,ipath,iwth,iht,ximg,ximg_ipath,ximg_iwth,ximg_iht;

    public String matches_id;
    public String match_desc;
    public String team1_name_new;
    public String team2_name_new;
    public String start_time;
    public String end_time;
}

